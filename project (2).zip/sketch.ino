// ============================================================
// PROJECT 4
// Edge-Computing Smart Home Appliance
// Interrupts & Safety
//
// ESP32-S3
// PIR Motion Sensor + MQ-2 Gas Sensor
// 3 Smart Lights + Red Fault LED + Buzzer
// ============================================================


// ---------------- PIN DEFINITIONS ----------------

const int PIR_PIN = 13;
const int GAS_PIN = 4;

const int LIGHT1_PIN = 18;
const int LIGHT2_PIN = 19;
const int LIGHT3_PIN = 21;

const int RED_LED_PIN = 26;
const int BUZZER_PIN = 14;


// ---------------- GAS SAFETY THRESHOLD ----------------
//
// ESP32 ADC normally gives a value from approximately
// 0 to 4095.
//
// Adjust this AFTER checking your Wokwi gas readings.

const int GAS_THRESHOLD = 2000;


// ---------------- PIR INTERRUPT VARIABLE ----------------

volatile bool motionDetected = false;


// ---------------- SYSTEM VARIABLES ----------------

bool safetyMode = false;

bool previousSafetyMode = false;

bool redLedState = false;

unsigned long lastRedFlash = 0;

const unsigned long RED_FLASH_INTERVAL = 300;


// ============================================================
// PIR INTERRUPT SERVICE ROUTINE
// ============================================================

void IRAM_ATTR pirInterrupt() {

  // Record the motion event immediately.
  motionDetected = true;
}


// ============================================================
// SETUP
// ============================================================

void setup() {

  Serial.begin(115200);


  // -------- INPUTS --------

  pinMode(PIR_PIN, INPUT);
  pinMode(GAS_PIN, INPUT);


  // -------- OUTPUTS --------

  pinMode(LIGHT1_PIN, OUTPUT);
  pinMode(LIGHT2_PIN, OUTPUT);
  pinMode(LIGHT3_PIN, OUTPUT);

  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);


  // -------- INITIAL STATE --------

  digitalWrite(LIGHT1_PIN, LOW);
  digitalWrite(LIGHT2_PIN, LOW);
  digitalWrite(LIGHT3_PIN, LOW);

  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);


  // ========================================================
  // HARDWARE INTERRUPT
  // PIR generates an interrupt when motion goes LOW → HIGH
  // ========================================================

  attachInterrupt(
    digitalPinToInterrupt(PIR_PIN),
    pirInterrupt,
    RISING
  );


  Serial.println();
  Serial.println("========================================");
  Serial.println(" EDGE-COMPUTING SMART HOME SYSTEM");
  Serial.println("========================================");
  Serial.println("System initialized.");
  Serial.println("Safety monitoring ACTIVE.");
  Serial.println();
}


// ============================================================
// TURN SMART LIGHTING ARRAY ON
// ============================================================

void lightsON() {

  digitalWrite(LIGHT1_PIN, HIGH);
  digitalWrite(LIGHT2_PIN, HIGH);
  digitalWrite(LIGHT3_PIN, HIGH);
}


// ============================================================
// TURN SMART LIGHTING ARRAY OFF
// ============================================================

void lightsOFF() {

  digitalWrite(LIGHT1_PIN, LOW);
  digitalWrite(LIGHT2_PIN, LOW);
  digitalWrite(LIGHT3_PIN, LOW);
}


// ============================================================
// ENTER SAFETY MODE
// ============================================================

void enterSafetyMode() {

  safetyMode = true;

  // SAFETY HAS ABSOLUTE PRIORITY

  // Immediately turn OFF all lights
  lightsOFF();

  // Turn buzzer ON
  digitalWrite(BUZZER_PIN, HIGH);

  // Reset flashing timer
  lastRedFlash = millis();

  Serial.println();
  Serial.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
  Serial.println("       !!! SAFETY ALERT !!!");
  Serial.println("       GAS / SMOKE DETECTED");
  Serial.println("       SAFETY OVERRIDE ACTIVE");
  Serial.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
}


// ============================================================
// EXIT SAFETY MODE
// ============================================================

void exitSafetyMode() {

  safetyMode = false;

  // Turn alarm OFF
  digitalWrite(BUZZER_PIN, LOW);

  // Turn red LED OFF
  digitalWrite(RED_LED_PIN, LOW);

  redLedState = false;

  Serial.println();
  Serial.println("----------------------------------------");
  Serial.println("Gas level returned to SAFE.");
  Serial.println("Safety override cleared.");
  Serial.println("System returned to NORMAL operation.");
  Serial.println("----------------------------------------");
}


// ============================================================
// SAFETY MODE PROCESSING
// ============================================================

void processSafetyMode() {

  // Lights MUST remain OFF
  lightsOFF();

  // Buzzer remains ON
  digitalWrite(BUZZER_PIN, HIGH);


  // Flash red LED without blocking the CPU

  if (millis() - lastRedFlash >= RED_FLASH_INTERVAL) {

    lastRedFlash = millis();

    redLedState = !redLedState;

    digitalWrite(RED_LED_PIN, redLedState);
  }
}


// ============================================================
// NORMAL MODE PROCESSING
// ============================================================

void processNormalMode() {

  // Safety indicators OFF
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(RED_LED_PIN, LOW);

  redLedState = false;


  // --------------------------------------------------------
  // MOTION EVENT FROM HARDWARE INTERRUPT
  // --------------------------------------------------------

  if (motionDetected) {

    motionDetected = false;

    Serial.println("Motion detected by PIR interrupt.");
    Serial.println("Smart lighting array -> ON");

    lightsON();
  }


  // --------------------------------------------------------
  // WHEN PIR IS NO LONGER ACTIVE
  // --------------------------------------------------------

  if (digitalRead(PIR_PIN) == LOW) {

    lightsOFF();
  }
}


// ============================================================
// MAIN LOOP
// ============================================================

void loop() {

  // ----------------------------------------------------------
  // READ GAS SENSOR
  // ----------------------------------------------------------

  int gasValue = analogRead(GAS_PIN);


  Serial.print("Gas/Smoke ADC: ");
  Serial.println(gasValue);


  // ----------------------------------------------------------
  // DETERMINE SAFETY CONDITION
  // ----------------------------------------------------------

  bool gasDetected = (gasValue >= GAS_THRESHOLD);


  // ----------------------------------------------------------
  // SAFETY STATE CHANGE
  // ----------------------------------------------------------

  if (gasDetected && !previousSafetyMode) {

    enterSafetyMode();
  }


  if (!gasDetected && previousSafetyMode) {

    exitSafetyMode();
  }


  // Update safety state
  previousSafetyMode = gasDetected;


  // ----------------------------------------------------------
  // HIGHEST-PRIORITY SYSTEM DECISION
  // ----------------------------------------------------------

  if (gasDetected) {

    // SAFETY OVERRIDES EVERYTHING
    processSafetyMode();

  }
  else {

    // NORMAL PIR-BASED OPERATION
    processNormalMode();
  }


  // Small non-blocking loop interval
  delay(10);
}